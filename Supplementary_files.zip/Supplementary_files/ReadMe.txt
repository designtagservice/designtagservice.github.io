Supplementary Material for:
"Machine Learning-Driven Routing Optimization for Energy-Efficient 6G-Enabled Wireless Sensor Networks"

This archive contains supplementary material, including source code, figures.

Contents:
1. Code- MATLAB code for routing optimization and ML training
2. Figures- High-resolution versions of result figures

