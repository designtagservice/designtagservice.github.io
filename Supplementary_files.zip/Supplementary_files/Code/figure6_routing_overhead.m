
rounds = 1:1000;
overhead_model = cumsum(1.4 + 0.2*rand(1,1000));
overhead_easp = cumsum(1.83 + 0.3*rand(1,1000));
overhead_dsr = cumsum(2.1 + 0.3*rand(1,1000));

plot(rounds, overhead_model, 'r', rounds, overhead_easp, 'b--', rounds, overhead_dsr, 'g-.');
xlabel('Rounds');
ylabel('Control Packets');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 6: Routing Overhead');
grid on;
