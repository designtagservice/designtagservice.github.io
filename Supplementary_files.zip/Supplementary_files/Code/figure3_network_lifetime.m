
rounds = 1:1000;
deaths_model = cumsum(rand(1,1000) < 0.01);
deaths_easp = cumsum(rand(1,1000) < 0.015);
deaths_dsr = cumsum(rand(1,1000) < 0.02);

plot(rounds, deaths_model, 'r', rounds, deaths_easp, 'b--', rounds, deaths_dsr, 'g-.');
xlabel('Rounds');
ylabel('Cumulative Dead Nodes');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 3: Network Lifetime');
grid on;
