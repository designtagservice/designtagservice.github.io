
rounds = 1:200;
q_values = cumsum(0.01*randn(1,200)) + linspace(0,1,200);
reward = smoothdata(100 * exp(-0.03 * rounds) + rand(1,200), 'movmean', 10);

yyaxis left;
plot(rounds, q_values, 'r');
ylabel('Q-values');

yyaxis right;
plot(rounds, reward, 'b--');
ylabel('Reward');

xlabel('Rounds');
title('Figure 9: Learning Convergence');
legend('Q-values', 'Reward');
grid on;
