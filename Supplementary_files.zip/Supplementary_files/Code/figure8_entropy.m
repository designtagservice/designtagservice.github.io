
rounds = 1:1000;
entropy_model = 0.79 + 0.01*randn(1,1000);
entropy_easp = 0.32 + 0.01*randn(1,1000);
entropy_dsr = 0.28 + 0.01*randn(1,1000);

plot(rounds, entropy_model, 'r', rounds, entropy_easp, 'b--', rounds, entropy_dsr, 'g-.');
xlabel('Rounds');
ylabel('Routing Entropy');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 8: Adaptive Routing Entropy');
grid on;
