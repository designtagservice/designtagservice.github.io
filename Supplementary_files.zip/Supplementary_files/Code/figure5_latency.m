
rounds = 1:1000;
delay_model = 108 + 5*randn(1,1000);
delay_easp = 136 + 5*randn(1,1000);
delay_dsr = 149 + 5*randn(1,1000);

plot(rounds, delay_model, 'r', rounds, delay_easp, 'b--', rounds, delay_dsr, 'g-.');
xlabel('Rounds');
ylabel('Latency (ms)');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 5: End-to-End Delay');
grid on;
