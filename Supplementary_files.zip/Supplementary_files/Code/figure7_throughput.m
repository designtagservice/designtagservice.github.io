
rounds = 1:1000;
throughput_model = 17.6 + randn(1,1000);
throughput_easp = 13.2 + randn(1,1000);
throughput_dsr = 11.5 + randn(1,1000);

plot(rounds, throughput_model, 'r', rounds, throughput_easp, 'b--', rounds, throughput_dsr, 'g-.');
xlabel('Rounds');
ylabel('Throughput (pkt/s)');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 7: Throughput');
grid on;
