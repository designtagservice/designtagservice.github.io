
rounds = 1:1000;
pdr_model = 93 + rand(1,1000);
pdr_easp = 82 + rand(1,1000);
pdr_dsr = 76 + rand(1,1000);

plot(rounds, pdr_model, 'r', rounds, pdr_easp, 'b--', rounds, pdr_dsr, 'g-.');
xlabel('Rounds');
ylabel('PDR (%)');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 4: Packet Delivery Ratio');
grid on;
