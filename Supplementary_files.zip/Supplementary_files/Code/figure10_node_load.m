
nodes = 1:100;
load_model = poissrnd(30, [1 100]);
bar(nodes, load_model);
xlabel('Node ID');
ylabel('Packets Forwarded');
title('Figure 10: Node Load Distribution');
grid on;
