
rounds = 1:1000;
energy_model = 0.52 - 0.0004 * rounds + 0.01 * rand(1,1000);
energy_easp = 0.38 - 0.0003 * rounds + 0.01 * rand(1,1000);
energy_dsr = 0.31 - 0.00025 * rounds + 0.01 * rand(1,1000);

plot(rounds, energy_model, 'r', rounds, energy_easp, 'b--', rounds, energy_dsr, 'g-.');
xlabel('Rounds');
ylabel('Average Energy (J)');
legend('Proposed Model', 'EASP', 'DSR');
title('Figure 1: Average Energy Consumption Over Time');
grid on;
