
residual_energy = [randn(1,100)*0.05 + 0.5, randn(1,100)*0.05 + 0.35, randn(1,100)*0.05 + 0.3];
group = [repmat({'Proposed Model'},1,100), repmat({'EASP'},1,100), repmat({'DSR'},1,100)];

boxplot(residual_energy, group);
ylabel('Residual Energy (J)');
title('Figure 2: Residual Energy Distribution');
grid on;
